package sistema_de_gestion;

public class ClaseGrupal extends Actividad implements Programar{
    
    int cant_max_participantes;
    
    public ClaseGrupal(String nombre, String entrenador_responsable, NivelIntensidad intensidad, int cant_max_participantes) {
        super(nombre, entrenador_responsable, intensidad);
        this.cant_max_participantes = cant_max_participantes;
    }
    
    public int get_max_participantes () {
        return cant_max_participantes;
    }
    
    @Override
    public void programarActividades() {
        System.out.println("Se programo la clase grupal");
    }
}
