package sistema_de_gestion;

public interface Programar {
    
    public void programarActividades ();
}
