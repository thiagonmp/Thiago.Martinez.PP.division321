package sistema_de_gestion;

import java.util.ArrayList;
import java.util.List;

public class CentroEntrenamiento {
    
    String Nombre;
    
    public CentroEntrenamiento (String nombre) {
        this.Nombre = nombre;
        this.actividades = new ArrayList<>();
    }
    
    private final ArrayList<Actividad> actividades;
    
    public static void main(String[] args) { 
        CentroEntrenamiento centro = new CentroEntrenamiento("Alto Rendimiento Sur"); 
 
        try { 
            centro.agregarActividad( 
                    new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25) 
            ); 
 
            centro.agregarActividad( 
                    new RutinaPersonalizada("Plan Fuerza Inicial", "Martin Diaz", 
NivelIntensidad.MEDIA, 8) 
            ); 
 
            centro.agregarActividad( 
                    new EvaluacionFisica("Evaluacion Ingreso", "Carla Suarez", 
NivelIntensidad.BAJA, 78) 
            ); 
 
            centro.agregarActividad( 
                    new RutinaPersonalizada("Plan Resistencia", "Laura Gomez", 
NivelIntensidad.ALTA, 6) 
            ); 
 
            centro.agregarActividad( 
                    new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20) 
            ); 
 
        } catch (ActividadDuplicadaException e) { 
            System.out.println("No se pudo agregar la actividad: " + e.getMessage()); 
        } 
 
        System.out.println("Actividades registradas:"); 
        mostrarActividades(centro.obtenerActividades()); 
 
        System.out.println(); 
 
        System.out.println("Actividades programables:"); 
        programarActividades(centro.obtenerActividades()); 
 
        System.out.println(); 
 
        System.out.println("Informes generados:"); 
        generarInformesDesdeMain(centro.obtenerActividades()); 
 
        System.out.println(); 
 
        System.out.println("Actividades de intensidad ALTA:"); 
        mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA)); 
    } 
 
    private static void mostrarActividades(List<Actividad> actividades) { 
        if (actividades.isEmpty()) {
        System.out.println("No hay actividades para mostrar.");
        return;
    }
    for (Actividad actividad : actividades) {
        System.out.println("Tipo: " + actividad.getClass().getSimpleName());
        System.out.println("Nombre: " + actividad.get_nombre());
        System.out.println("Entrenador responsable: " + actividad.get_entrenador());
        System.out.println("Intensidad: " + actividad.get_intensidad());

        if (actividad instanceof ClaseGrupal) {
            ClaseGrupal grupal = (ClaseGrupal) actividad;
            System.out.println("Cantidad máxima de participantes: " + grupal.get_max_participantes());
        } else if (actividad instanceof RutinaPersonalizada) {
            RutinaPersonalizada rutina = (RutinaPersonalizada) actividad;
            System.out.println("Duración de la rutina: " + rutina.get_duracion() + " semanas");
        } else if (actividad instanceof EvaluacionFisica) {
            EvaluacionFisica eval = (EvaluacionFisica) actividad;
            System.out.println("Puntaje: " + eval.get_puntaje());
        }
        System.out.println(" - ");
    }
    } 
 
    private static void programarActividades(List<Actividad> actividades) { 
        for (Actividad actividad : actividades) {
        if (actividad instanceof ClaseGrupal) {
            ((ClaseGrupal) actividad).programarActividades();
            System.out.println(actividad.get_nombre());
        } else if (actividad instanceof RutinaPersonalizada) {
            ((RutinaPersonalizada) actividad).programarActividades();
            System.out.println(actividad.get_nombre());
        }
    }
    }
        
    private static void generarInformesDesdeMain(List<Actividad> actividades) { 
        for (Actividad actividad : actividades) {
        if (actividad instanceof EvaluacionFisica) {
            ((EvaluacionFisica) actividad).generar_informe();
            System.out.println(actividad.get_nombre());
        } else if (actividad instanceof RutinaPersonalizada) {
            ((RutinaPersonalizada) actividad).generar_informe();
            System.out.println(actividad.get_nombre());
            }
        }
    }
    
    
    
    
    
    public void agregarActividad(Actividad new_actividad) {
        try {
            actividadExiste(new_actividad);
            actividades.add(new_actividad);
        } catch (ActividadDuplicadaException ex){
            System.out.println(ex.getMessage() + ": ya exite una actividad con nombre ´" + new_actividad.get_nombre() + "´ y entrenador ´" + new_actividad.get_entrenador() + "´" );
        }
    }
    
    public void actividadExiste (Actividad actividad) {
        for (Actividad actividadExiste : actividades) {
            if (actividadExiste.get_nombre().equals(actividad.get_nombre()) &&
                actividadExiste.get_entrenador().equals(actividad.get_entrenador())) {
                throw new ActividadDuplicadaException();
            }
        }
    }
    
    public List<Actividad> filtrarPorNivel(NivelIntensidad intensidad) {
        List<Actividad> filtradas = new ArrayList<>();
        for (Actividad actividad : actividades) {
            if (actividad.get_intensidad().equals(intensidad)) {
                filtradas.add(actividad);
            }
        }
        return filtradas;
    }
   
    public List<Actividad> obtenerActividades() {
    return new ArrayList<>(actividades);
}
}
