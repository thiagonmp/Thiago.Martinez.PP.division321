package sistema_de_gestion;

public class RutinaPersonalizada extends Actividad implements Programar, Informe{
    
    int duracion_semanas;
    
    public RutinaPersonalizada(String nombre, String entrenador_responsable, NivelIntensidad intensidad, int duracion_semanas) {
        super(nombre, entrenador_responsable, intensidad);
        this.duracion_semanas = duracion_semanas;
    }
    
    public int get_duracion () {
        return duracion_semanas;
    }
    
    @Override
    public void programarActividades() {
        System.out.println("Programando rutina personal");
    }
    
    @Override
    public void generar_informe() {
        System.out.println("Generando informe de rutina personal");
    }
}
