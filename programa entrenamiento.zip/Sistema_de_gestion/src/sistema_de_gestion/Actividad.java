package sistema_de_gestion;

public abstract class Actividad {
    
    String nombre;
    String entrenador_responsable;
    NivelIntensidad intensidad;
    
    public Actividad (String nombre, String entrenador_responsable, NivelIntensidad intensidad) {
        this.nombre = nombre;
        this.entrenador_responsable = entrenador_responsable;
        this.intensidad = intensidad; 
    }
    
    public String get_nombre () {
        return nombre;
    }
    
    public String get_entrenador () {
        return entrenador_responsable;
    }
    
    public NivelIntensidad get_intensidad () {
        return intensidad;
    }
}
