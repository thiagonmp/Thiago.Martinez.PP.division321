package sistema_de_gestion;

public class EvaluacionFisica extends Actividad implements Informe{
    
    int puntaje;
    
    public EvaluacionFisica(String nombre, String entrenador_responsable, NivelIntensidad intensidad, int puntaje) {
        super(nombre, entrenador_responsable, intensidad);
        this.puntaje = puntaje;
    }
    
    public int get_puntaje () {
        return puntaje;
    }
    
    @Override
    public void generar_informe() {
        System.out.println("Generando informe de rutina personal");
    }
}
