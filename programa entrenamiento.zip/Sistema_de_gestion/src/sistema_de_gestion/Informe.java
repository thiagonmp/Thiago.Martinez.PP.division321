package sistema_de_gestion;

public interface Informe {
    
    public void generar_informe ();
}
