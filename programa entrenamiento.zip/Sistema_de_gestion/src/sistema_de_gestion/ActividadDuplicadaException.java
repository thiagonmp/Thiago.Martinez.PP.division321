package sistema_de_gestion;

public class ActividadDuplicadaException extends RuntimeException{
    
    
    private static final String MESSAGE = "ERROR: No se pudo agregar la actividad";
    
    public ActividadDuplicadaException() {
        this(MESSAGE);
    }
    
    public ActividadDuplicadaException(String message) {
        super(message);
    }
}
