package sistema_de_gestion;

public enum NivelIntensidad {
    BAJA,
    MEDIA,
    ALTA
}
