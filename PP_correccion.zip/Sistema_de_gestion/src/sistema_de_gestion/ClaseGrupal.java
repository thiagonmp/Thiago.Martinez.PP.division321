package sistema_de_gestion;

public class ClaseGrupal extends Actividad implements Programar{
    
    int cant_max_participantes;
    
    public ClaseGrupal(String nombre, String entrenador_responsable, NivelIntensidad intensidad, int cant_max_participantes) {
        super(nombre, entrenador_responsable, intensidad);
        this.cant_max_participantes = validarMaxParticipantes(cant_max_participantes);
    }
    
    private int validarMaxParticipantes(int participantes) {
        if (participantes <= 0) {
            throw new IllegalArgumentException("La cantidad máxima de participantes debe ser mayor a cero.");
        }
        return participantes;
    }
    
    public int get_max_participantes () {
        return cant_max_participantes;
    }
    
    @Override
    public void programarActividades() {
        System.out.println("Se programo la clase grupal");
    }
    
    @Override
    public String toString () {
        return "\nActividad: Clase grupal \nNombre: " + get_nombre() + "\nEntrenador: " 
                + get_entrenador() + "\nIntensidad: " + get_intensidad() + "\nCantidad de participantes: " + get_max_participantes();
    }
}
