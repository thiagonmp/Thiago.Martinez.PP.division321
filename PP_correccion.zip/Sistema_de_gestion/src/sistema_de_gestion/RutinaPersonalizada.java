package sistema_de_gestion;

public class RutinaPersonalizada extends Actividad implements Programar, Informe{
    
    int duracion_semanas;
    
    public RutinaPersonalizada(String nombre, String entrenador_responsable, NivelIntensidad intensidad, int duracion_semanas) {
        super(nombre, entrenador_responsable, intensidad);
        this.duracion_semanas = validarSemanas(duracion_semanas);
    }
    
    private int validarSemanas(int duracion_semanas) {
        if (duracion_semanas <= 0) {
            throw new IllegalArgumentException("La cantidad de semanas debe ser superior a cero.");
        }
        return duracion_semanas;
    }
    
    public int get_duracion () {
        return duracion_semanas;
    }
    
    @Override
    public void programarActividades() {
        System.out.println("Programando rutina personal");
    }
    
    @Override
    public void generar_informe() {
        System.out.println("Generando informe de rutina personal");
    }
    
    @Override
    public String toString () {
        return "\nActividad: Clase grupal \nNombre: " + get_nombre() + "\nEntrenador: " 
                + get_entrenador() + "\nIntensidad: " + get_intensidad() + "\nDuracion: " + get_duracion() + " semanas";
    }
}
