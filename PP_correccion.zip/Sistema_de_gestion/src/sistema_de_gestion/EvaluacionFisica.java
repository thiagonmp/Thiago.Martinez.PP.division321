package sistema_de_gestion;

public class EvaluacionFisica extends Actividad implements Informe{
    
    int puntaje;
    
    public EvaluacionFisica(String nombre, String entrenador_responsable, NivelIntensidad intensidad, int puntaje) {
        super(nombre, entrenador_responsable, intensidad);
        this.puntaje = validarPuntaje(puntaje);
    }
    
    private int validarPuntaje(int puntaje) {
        if (puntaje <= 0 || puntaje > 100) {
            throw new IllegalArgumentException("el puntaje debe estar entre 1 y 100.");
        }
        return puntaje;
    }
    
    public int get_puntaje () {
        return puntaje;
    }
    
    @Override
    public void generar_informe() {
        System.out.println("Generando informe de rutina personal");
    }
    
    @Override
    public String toString () {
        return "\nActividad: Clase grupal \nNombre: " + get_nombre() + "\nEntrenador: " 
                + get_entrenador() + "\nIntensidad: " + get_intensidad() + "\nPuntaje: " + get_puntaje();
    }
}
