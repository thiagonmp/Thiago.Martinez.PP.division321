package sistema_de_gestion;

import java.util.ArrayList;
import java.util.List;

public class CentroEntrenamiento {
    
    String Nombre;
    
    public CentroEntrenamiento (String nombre) {
        this.Nombre = nombre;
        this.actividades = new ArrayList<>();
    }
    
    private final ArrayList<Actividad> actividades;
    
    public void agregarActividad(Actividad new_actividad) {
        try {
            actividadExiste(new_actividad);
            actividades.add(new_actividad);
        } catch (ActividadDuplicadaException ex){
            System.out.println(ex.getMessage() + ": ya exite una actividad con nombre ´" + new_actividad.get_nombre() + "´ y entrenador ´" + new_actividad.get_entrenador() + "´" );
        }
    }
    
    public void actividadExiste (Actividad actividad) {
        for (Actividad actividadExiste : actividades) {
            if (actividadExiste.get_nombre().equals(actividad.get_nombre()) &&
                actividadExiste.get_entrenador().equals(actividad.get_entrenador())) {
                throw new ActividadDuplicadaException();
            }
        }
    }
    
    public List<Actividad> filtrarPorNivel(NivelIntensidad intensidad) {
        List<Actividad> filtradas = new ArrayList<>();
        for (Actividad actividad : actividades) {
            if (actividad.get_intensidad().equals(intensidad)) {
                filtradas.add(actividad);
            }
        }
        return filtradas;
    }
    
    public List<Actividad> obtenerActividades() {
    return new ArrayList<>(actividades);
}
}
